function distance = findEuclideanDistance(startpt,endpt)
    distance = norm(startpt-endpt);
end